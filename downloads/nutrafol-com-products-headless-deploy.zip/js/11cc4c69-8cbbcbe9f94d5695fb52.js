"use strict";(self.webpackChunknutrafol=self.webpackChunknutrafol||[]).push([[19210],{97909:function(t,e,i){i.d(e,{$d:function(){return I},$g:function(){return y},Au:function(){return $},Bh:function(){return A},Et:function(){return k},Is:function(){return G},JC:function(){return b},PP:function(){return B},VU:function(){return g},WF:function(){return s},X6:function(){return z},Xl:function(){return c},Zg:function(){return F},Zx:function(){return x},_N:function(){return h},_h:function(){return u},_q:function(){return m},h8:function(){return w},im:function(){return C},jI:function(){return p},n5:function(){return q},oR:function(){return r},wl:function(){return P},xv:function(){return v}});var a=i(74316),d=i(66455),n=i(52221),l=i(2059),o=i(61354),f=i(78735);const r=(0,a.default)("div",{target:"ezab7xb51"})("padding:40px 0;@media (max-width: 1024px){padding:32px 0;}background:",o.default.color.beige,';min-height:calc(100vh - 450px);*:not(\n      a,\n      button *,\n      button,\n      [class*="text-"],\n      .action-link,\n      .visual-name,\n      .optional\n    ){color:#22202f;}label.has-value{color:#677574;}a{color:#007a73;}&.loading{opacity:0.25;}&.pt-0{padding-top:0;}',l.o.medium`
    min-height: calc(100vh - 290px);
  `," .AccountPageContainerAlt{padding-top:0;padding-bottom:15px;@media (min-width: 768px){padding-top:0;padding-bottom:15px;}}"),u=(o.default.spacing.medium,l.o.medium`
    min-height: calc(100vh - 290px);
  `,(0,a.default)("div",{target:"ezab7xb49"})({name:"1dysn9n",styles:"padding:0 16px;@media (min-width: 768px){padding:0;}"})),m=(0,a.default)("div",{target:"ezab7xb48"})({name:"j7w71m",styles:"width:100%;max-width:1520px;padding:32px 16px;margin-left:auto;margin-right:auto;@media (min-width: 768px){padding:40px 8px;}@media (min-width: 1024px){padding:40px 40px;}@media (min-width: 1600px){padding:40px 0px;}"}),g=(o.default.wild.color.master.base.black,o.default.wild.font.grilli.book,o.default.weight.light,l.o.medium`
    font-size: 44px;
    line-height: 60px;
  `,o.default.wild.font.dinamo.bold,o.default.weight.demi,l.o.medium`
    font-size: 24px;
    line-height: 32px;
  `,o.default.spacing.small,o.default.wild.font.grilli.book,o.default.weight.book,o.default.wild.font.dinamo.bold,o.default.weight.demi,l.o.medium`
    font-size: 32px;
    line-height: 28px;
    margin-bottom: ${o.default.spacing.medium};
  `,(0,a.default)("h2",{target:"ezab7xb44"})("font-size:18px;line-height:26px;margin-bottom:",o.default.spacing.small,";font-family:",o.default.wild.font.dinamo.regular,";font-weight:",o.default.weight.book,";b,&.demi{font-family:",o.default.wild.font.dinamo.bold,";font-weight:",o.default.weight.demi,";}",l.o.medium`
    font-size: 24px;
    line-height: 36px;
    margin-bottom: ${o.default.spacing.medium};
  `,";")),p=(0,a.default)("h2",{target:"ezab7xb43"})("font-size:18px;line-height:24px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:",o.default.weight.book,";margin-bottom:",o.default.spacing.small,";b,&.demi{font-family:",o.default.wild.font.dinamo.bold,";font-weight:",o.default.weight.demi,";}",l.o.medium`
    font-family: ${o.default.wild.font.grilli.book};
    font-weight: ${o.default.weight.light};
    font-size: 24px;
    line-height: 32px;
    margin-bottom: ${o.default.spacing.medium};
  `,";"),x=(o.default.wild.font.dinamo.regular,o.default.weight.regular,l.o.medium`
    margin: 40px 0;
    font-size: 28px;
    line-height: 37px;
  `,o.default.wild.font.dinamo.regular,o.default.weight.regular,l.o.medium`
    margin: 0;
    font-size: 20px;
    line-height: 26px;
  `,o.default.wild.font.dinamo.regular,o.default.weight.book,o.default.spacing.small,o.default.wild.font.dinamo.bold,o.default.weight.demi,l.o.medium`
    font-family: ${o.default.wild.font.grilli.book};
    font-weight: ${o.default.weight.light};
    font-size: 32px;
    line-height: 44px;
    margin-bottom: ${o.default.spacing.medium};
  `,o.default.color.white,o.default.spacing.medium,l.o.medium`
    .c-right {
     text-align: right;
    }
    padding: ${o.default.spacing.large} ${o.default.spacing.medium};
    &.padded-sm {
      padding: ${o.default.spacing.medium};
    }
    &.padded-lg {
      padding: 50px 35px;
    }
  `,l.o.large`
    &.padded-lg {
      padding: 50px 65px;
    }
  `,o.default.wild.font.dinamo.regular,o.default.wild.font.dinamo.bold,o.default.weight.demi,o.default.spacing.small,o.default.wild.color.master.base.black,l.o.medium`
    font-size: 24px;
    line-height: 32px;
    margin-bottom: ${o.default.spacing.medium};
  `,(0,a.default)("button",{target:"ezab7xb37"})("font-family:",o.default.wild.font.dinamo.mono,";font-weight:",o.default.weight.mono,";text-decoration:none;border-bottom:1px solid ",o.default.wild.color.master.primary.default,";color:",o.default.wild.color.master.primary.default,";font-size:12px;line-height:130%;",l.o.medium`
  font-size: 14px;
  `," ",l.o.large`
  font-size: 16px;
  `," &.c-schedule{min-width:156px;}")),s=(o.default.wild.font.dinamo.regular,o.default.weight.mono,o.default.wild.color.master.primary.default,(0,a.default)(d.Box,{target:"ezab7xb35"})("height:1px;width:100%;background:",o.default.color.lightGray,";&.light{background:rgba(34, 32, 47, 0.3);}&.lighter{background:#e4e4e4;}")),h=(o.default.wild.color.master.base.black,o.default.wild.font.dinamo.regular,o.default.weight.book,o.default.wild.font.dinamo.bold,o.default.weight.demi,(0,a.default)("p",{target:"ezab7xb33"})("font-size:16px;line-height:22px;color:",o.default.wild.color.master.base.black,";font-family:",o.default.wild.font.dinamo.regular,";font-weight:",o.default.weight.book,";b,&.demi{font-family:",o.default.wild.font.dinamo.bold,";font-weight:",o.default.weight.demi,";}")),b=(o.default.wild.font.dinamo.bold,o.default.weight.demi,(0,a.default)("h3",{target:"ezab7xb31"})("color:rgb(34, 32, 47);font-size:12px;font-family:",o.default.wild.font.dinamo.mono,";font-weight:normal;text-transform:uppercase;letter-spacing:0.2px;line-height:18px;&.light{color:",o.default.color.lightGray,";}")),c=(o.default.wild.font.dinamo.bold,o.default.weight.demi,o.default.wild.color.master.primary.default,o.default.wild.font.dinamo.bold,o.default.weight.demi,o.default.wild.color.master.primary.default,o.default.color.lightGray,o.default.wild.font.dinamo.bold,o.default.weight.demi,o.default.wild.color.master.primary.default,o.default.color.lightGray,o.default.wild.font.dinamo.mono,o.default.weight.mono,o.default.wild.color.master.primary.default,o.default.wild.color.master.primary.default,(0,a.default)(d.Flex,{target:"ezab7xb27"})("color:rgb(34, 32, 47);font-size:14px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:300;letter-spacing:0;")),w=(0,a.default)("div",{target:"ezab7xb26"})("color:rgb(34, 32, 47);font-size:22px;line-height:30px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:",o.default.weight.book,";letter-spacing:0px;margin:0 0 ",o.default.spacing.medium," 0;.mobile-br{display:block;",l.o.medium`
      display: inline;
    `,";}",l.o.medium`
    font-family: ${o.default.wild.font.grilli.book};
    font-weight: ${o.default.weight.light};
    font-size: 28px;
    line-height: 36px;
  `,";"),y=(0,a.default)("div",{target:"ezab7xb25"})({name:"e3sgoq",styles:".InputCheckbox{span{font-size:14px;}}@media (max-width: 1023px){h3{font-size:12px!important;}}"}),z=(o.default.spacing.small,o.default.spacing.medium,o.default.spacing.small,f.Z,o.default.wild.color.master.base.black,o.default.wild.font.dinamo.regular,o.default.weight.book,o.default.spacing.medium,(0,a.default)("div",{target:"ezab7xb22"})("color:rgb(34, 32, 47);font-size:28px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:300;letter-spacing:0px;line-height:37px;margin:0 0 24px 0;&.c-center{text-align:center;}")),k=(0,a.default)("div",{target:"ezab7xb21"})({name:"7uefi3",styles:"padding:0;.InputCheckboxWild{span{font-size:14px;}}input{cursor:pointer;}.mono{margin:15px 0;}.c-readonly{input{opacity:0.3!important;}}"}),v=(0,a.default)("div",{target:"ezab7xb20"})("color:rgb(34, 32, 47);font-size:16px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:300;text-align:center;letter-spacing:0;line-height:24px;"),$=(0,a.default)("div",{target:"ezab7xb19"})("color:rgb(34, 32, 47);font-size:16px;font-family:",o.default.wild.font.dinamo.regular,";font-weight:300;text-align:center;letter-spacing:0;line-height:24px;padding:16px 0 0;border-top:2px #ddd solid;*{text-align:left;font-size:14px;font-weight:bold;}"),C=(0,a.default)("div",{target:"ezab7xb18"})({name:"qt1fzi",styles:".c-btn{margin:30px auto 0;display:block;}&.hide{display:none;}.slick-list{transition:height 250ms linear;}.slick-slide{padding-left:1px;padding-right:1px;}*,*:focus{outline:none!important;}"}),B=(o.default.wild.font.dinamo.regular,o.default.wild.font.dinamo.regular,o.default.wild.font.dinamo.regular,o.default.wild.font.dinamo.regular,o.default.spacing.medium,(0,a.default)(d.Flex,{target:"ezab7xb7"})({name:"1fuu5ov",styles:"display:flex;flex-direction:column;background:#ffffff;border-radius:8px;padding:16px;@media (min-width: 360px){padding:32px;}@media (min-width: 1024px){flex:1;}@media (min-width: 1280px){padding:64px;}"})),q=(0,a.default)("div",{target:"ezab7xb6"})({name:"90ysfy",styles:'width:100%;label{cursor:pointer;}.c-CloseWrapper{display:none;}.c-btn-submit{margin:0 32px 0 0;}.btn{text-transform:none;width:100%;}.secondField{@media (min-width: 768px){margin-left:16px;}}.inputProfile{margin-bottom:8px;color:#677574;}.checkbox-wrapper>div{margin-bottom:0;display:flex;}.checkbox-wrapper label>div{display:flex;align-items:center;}.checkbox-wrapper input[type="checkbox"]{display:flex;}.checkbox-wrapper p{line-height:1;@media (max-width: 1023px){font-size:12px;margin-top:1px;}}'}),F=(0,a.default)(d.Box,{target:"ezab7xb5"})({name:"na4t4d",styles:"width:100%;*{text-align:center;}.btn{width:100%;text-transform:none;}"}),G=(0,a.default)("div",{target:"ezab7xb3"})("padding-bottom:",(t=>t.isLast?"0":"32px"),";margin-bottom:",(t=>t.isLast?"0":"32px"),";border-bottom:",(t=>t.isLast?"none":"1px solid #C8D2D1"),";"),I=(0,a.default)(d.Box,{target:"ezab7xb2"})({name:"1qsuvl4",styles:"background:transparent"}),P=(0,a.default)(d.Box,{target:"ezab7xb1"})({name:"4zfu6",styles:".rewards-box{box-shadow:0px 1.75px 2.31px 0px rgba(0, 0, 0, 0.0098),0px 8px 6.5px 0px rgba(0, 0, 0, 0.015),0px 20.25px 17.44px 0px rgba(0, 0, 0, 0.0203),0px 40px 40px 0px rgba(0, 0, 0, 0.03);}"}),A=(0,a.default)(d.Box,{target:"ezab7xb0"})({name:"1lwr7em",styles:"background:#fff;border-radius:8px;padding:16px;@media (min-width: 360px){padding:32px;}@media (min-width: 1024px){padding:64px;}"})}}]);
//# sourceMappingURL=11cc4c69-8cbbcbe9f94d5695fb52.js.map