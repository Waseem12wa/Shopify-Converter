// Shopify Headless Configuration
// Generated automatically via UI

const SHOPIFY_CONFIG = {
    domain: 'zf0rmz-nd.myshopify.com',
    storefrontAccessToken: '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',
    
    // Map detected buttons to Shopify Variant IDs
    productMapping: {
    "Take The Quiz": {
        "variantId": "gid://shopify/ProductVariant/47285202125036",
        "action": "checkout"
    }
}
};

window.SHOPIFY_CONFIG = SHOPIFY_CONFIG;
